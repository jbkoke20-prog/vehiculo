/*
 * Programa: MainVehiculo.java
 * Propósito: Leer datos de un vehículo desde teclado y mostrarlos por pantalla.
 * Compilación: javac MainVehiculo.java
 * Ejecución:   java MainVehiculo
 */
import java.util.Scanner;

public class MainVehiculo {
    public static void main(String[] args) {
        // Crear un lector para entrada estándar (teclado)
        Scanner scanner = new Scanner(System.in);

        // Declaración de variables
        String marca;
        String modelo;
        String cilindrada;
        String tipoCombustible;
        int capacidadPasajeros;

        // Solicitud y lectura de datos
        System.out.print("Ingrese la marca: ");
        marca = scanner.nextLine();

        System.out.print("Ingrese el modelo: ");
        modelo = scanner.nextLine();

        System.out.print("Ingrese la cilindrada: ");
        cilindrada = scanner.nextLine();

        System.out.print("Ingrese el tipo de combustible: ");
        tipoCombustible = scanner.nextLine();

        System.out.print("Ingrese la capacidad en pasajeros (número entero): ");
        capacidadPasajeros = Integer.parseInt(scanner.nextLine());

        // Salida formateada
        System.out.println("La marca que ha ingresado es: " + marca);
        System.out.println("El modelo que ha ingresado es: " + modelo);
        System.out.println("La cilindrada que ha ingresado es: " + cilindrada);
        System.out.println("El tipo de combustible es: " + tipoCombustible);
        System.out.println("Tiene una capacidad de " + capacidadPasajeros + " pasajeros.");

        // Cerrar el scanner para liberar recursos
        scanner.close();
    }
}
