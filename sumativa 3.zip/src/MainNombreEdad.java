/*
 * Programa: MainNombreEdad.java
 * Propósito: Pedir nombre y edad y mostrarlos por pantalla (según formato del informe).
 * Compilación: javac MainNombreEdad.java
 * Ejecución:   java MainNombreEdad
 */
import java.util.Scanner;

public class MainNombreEdad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese su nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Ingrese su edad: ");
        int edad = Integer.parseInt(scanner.nextLine());

        System.out.println("Nombre ingresado: " + nombre);
        System.out.println("Edad ingresada: " + edad);

        scanner.close();
    }
}
